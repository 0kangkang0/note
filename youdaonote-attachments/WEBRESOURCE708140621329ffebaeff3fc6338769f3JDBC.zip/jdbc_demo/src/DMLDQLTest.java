import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DMLDQLTest {
    /**
     * 执行DML
     * @throws Exception
     */
    @Test
    public void testDML() throws Exception {
        //1、获取链接
        Connection conn = DriverManager.getConnection("jdbc:mysql:///db1?useSSL=false",
                "root", "1234");
        //2定义sql
        String sql = "update account set money = 3000 where id = 1";
        //3、获取执行sql的对象
        Statement stmt = conn.createStatement();
        System.out.println(stmt.executeUpdate(sql));
        stmt.close();
        conn.close();
    }

    /**
     * 执行DDL
     * @throws Exception
     */
    @Test
    public void testDDL() throws Exception {
        //1、获取链接
        Connection conn = DriverManager.getConnection("jdbc:mysql:///db1?useSSL=false",
                "root", "1234");
        //2定义sql
        String sql = "create database db2";
        //3、获取执行sql的对象
        Statement stmt = conn.createStatement();
        System.out.println(stmt.executeUpdate(sql));
        stmt.close();
        conn.close();
    }
}