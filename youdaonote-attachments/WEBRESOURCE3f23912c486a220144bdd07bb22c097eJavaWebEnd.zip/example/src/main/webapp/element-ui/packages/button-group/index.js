import ElButtonGroup from '../button/src/button-group';

/* istanbul ignore next */
ElButtonGroup.install = function(Vue) {
  Vue.component(ElButtonGroup.name, ElButtonGroup);
};

export default ElButtonGroup;
