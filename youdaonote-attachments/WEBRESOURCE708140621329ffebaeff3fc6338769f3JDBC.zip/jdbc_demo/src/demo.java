import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class demo {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Connection coon = DriverManager.getConnection("jdbc:mysql:///db1", "root", "1234");
        String sql="insert into stu value (null,'乙','2022-09-10',19,1.77)";
        Statement stmt = coon.createStatement();
        int i = stmt.executeUpdate(sql);
        System.out.println(i);
        stmt.close();
        coon.close();
    }
}
