import org.junit.jupiter.api.Test;

import java.sql.*;

public class ResultSetDemo {
    @Test
    public void testResultSet() throws SQLException {
        //1、获取链接
        Connection conn = DriverManager.getConnection("jdbc:mysql:///db1?useSSL=false",
                "root", "1234");
        //2定义sql
        String sql = "select * from account";
        //3、获取执行sql的对象
        Statement stmt = conn.createStatement();
        //4、执行sql
        ResultSet rs = stmt.executeQuery(sql);
        //5、处理结果
        /*
        // 5.1 光标向下移动一行，并且判断当前行是否有数据
        while (rs.next()){
            //5.2 获取数据  getXxx()
            int id = rs.getInt(1);
            String name = rs.getString(2);
            double money = rs.getDouble(3);
            System.out.println(id);
            System.out.println(name);
            System.out.println(money);
            System.out.println("--------------");
        }
        //*/
        // 5.1 光标向下移动一行，并且判断当前行是否有数据
        while (rs.next()){
            //5.2 获取数据  getXxx()
            int id = rs.getInt("id");
            String name = rs.getString("name");
            double money = rs.getDouble("money");
            System.out.println(id);
            System.out.println(name);
            System.out.println(money);
            System.out.println("--------------");
        }
        //6. 释放资源
        rs.close();
        stmt.close();
        conn.close();
    }
}
