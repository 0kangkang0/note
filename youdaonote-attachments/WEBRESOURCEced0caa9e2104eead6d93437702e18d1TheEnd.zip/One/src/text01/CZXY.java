package text01;

public class CZXY implements MyService{
    @Override
    public void service() {
        System.out.println("传智学院");
    }
}
