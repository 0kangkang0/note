import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionDemo {
    public static void main(String[] args) throws Exception {
        //1、获取链接
        Connection conn = DriverManager.getConnection("jdbc:mysql:///db1?useSSL=false",
                "root", "1234");
        //2定义sql
        String sql1 = "update account set money = 3000 where id = 1";
        String sql2 = "update account set money = 3000 where id = 2";
        //3、获取执行sql的对象
        Statement stmt= conn.createStatement();
        try{
            //开启事务
            conn.setAutoCommit(false);
            //执行sql
            System.out.println(stmt.executeUpdate(sql1));
            //制造异常
            //int i=1/0;
            System.out.println(stmt.executeUpdate(sql2));
            //提交事务
            conn.commit();
        }catch (Exception e){
            //回滚事务
            conn.rollback();
            e.printStackTrace();
        }
        stmt.close();
        conn.close();
    }
}
