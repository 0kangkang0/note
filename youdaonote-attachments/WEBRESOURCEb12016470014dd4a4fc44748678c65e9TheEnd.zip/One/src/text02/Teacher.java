package text02;

public class Teacher {
    public void teach(){
        System.out.println("教书育人");
    }
}
