import text01.MyService;

module Two {
    requires One;

    uses MyService;
}