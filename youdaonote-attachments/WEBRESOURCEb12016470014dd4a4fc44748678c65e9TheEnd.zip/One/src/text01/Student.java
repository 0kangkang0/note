package text01;

public class Student {
    public void study(){
        System.out.println("好好学习");
    }
}
