package text03;

import text01.Student;

public class text {
    public static void main(String[] args) {
        Student student = new Student();
        student.study();
    }
}
