package text02;

import text01.MyService;

import java.security.Provider;
import java.util.ServiceLoader;

public class text {
    public static <MyServices> void main(String[] args) {
        ServiceLoader<MyService> myServices = ServiceLoader.load(MyService.class);
        for (MyService myService:myServices)
            myService.service();
    }
}
