package text01;

public class ITheima implements MyService{
    @Override
    public void service() {
        System.out.println("黑马程序员");
    }
}
