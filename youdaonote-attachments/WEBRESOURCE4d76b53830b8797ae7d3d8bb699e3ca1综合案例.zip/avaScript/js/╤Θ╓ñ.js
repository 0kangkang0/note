/*检测用户名*/
//获取用户名输入框
let username = document.getElementById("username");
//1.2 绑定onblur事件 失去焦点
username.onblur = checkUsername;
function checkUsername(){
    let trim = username.value.trim();
    let reg=/^\w{6,12}$/;
    let flag = reg.test(trim);
    if(flag){
        document.getElementById("username_err").style.display = "none";
    }else {
        document.getElementById("username_err").style.display = "";
    }
    return flag;
}
//验证密码
let password = document.getElementById("password");
password.onblur =checkPassword;
function checkPassword(){
    let trim = password.value.trim();
    let reg=/^\w{6,12}$/;
    let flag = reg.test(trim);
    if(flag){
        document.getElementById("password_err").style.display = "none";
    }else {
        document.getElementById("password_err").style.display = "";
    }
    return flag;
}
//验证手机号
let tel = document.getElementById("tel");
tel.onblur = checkTel;
function checkTel(){
    let trim = tel.value.trim();
    let reg=/^[1]\d{10}$/;
    let flag = reg.test(trim);
    if (flag){
        document.getElementById("tel_err").style.display = "none";
    }else {
        document.getElementById("tel_err").style.display = "";
    }
}