import text01.CZXY;
import text01.ITheima;
import text01.MyService;

module One {
    exports text01;
    provides MyService with CZXY;
    //provides MyService with ITheima;
}