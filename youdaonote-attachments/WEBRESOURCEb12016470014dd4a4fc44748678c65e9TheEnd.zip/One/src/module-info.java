module One {
    exports text01;
}