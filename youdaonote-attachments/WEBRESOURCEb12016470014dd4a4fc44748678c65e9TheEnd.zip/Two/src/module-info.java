module Two {
    requires One;
}