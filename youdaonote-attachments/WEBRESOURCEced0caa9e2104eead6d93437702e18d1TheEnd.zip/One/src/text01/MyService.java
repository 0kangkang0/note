package text01;

public interface MyService {
    void service();
}
